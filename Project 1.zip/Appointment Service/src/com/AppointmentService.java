package com;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    // Declare a map to store appointments
    private Map<String, Appointment> appointmentsMap;

    // Constructor to initialize the AppointmentService
    public AppointmentService() {
    	appointmentsMap = new HashMap<>();
    }

    // Add a appointment to the AppointmentService
    public void addAppointment(Appointment appointment) {
        // Check if the appointment ID already exists
        String appointmentID = appointment.getAppointmentID();
        if (appointmentsMap.containsKey(appointmentID)) {
            throw new IllegalArgumentException("Appointment ID already exists.");
        }

        // Add the task to the appointment map
        appointmentsMap.put(appointmentID, appointment);
    }

    // Delete a appointment to the AppointmentService
    public void deleteAppointment(String appointmentID) {
        // Check if the appointment ID exists
        if (!appointmentsMap.containsKey(appointmentID)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }

        // Remove the appointment from the Appointments map
        appointmentsMap.remove(appointmentID);
    }
	  
 // Getter to retrieve the appointmentsMap
 	public Map<String, Appointment> getAppointments() {
         return appointmentsMap;
     }

}
