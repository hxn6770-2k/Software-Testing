package com;

import java.util.Date;

public class Appointment {
	// Declare private member variables
	private String appointmentID;
    private Date appointmentDate;
    private String description;

    // Constructor to initialize the Appointment object
    public Appointment(String appointmentID, Date appointmentDate, String description) {
    	// Check the validity of input fields
    	checkStringField(appointmentID, 10, "Appointment ID");
        checkValidDate(appointmentDate);
        checkStringField(description, 50, "Description");
    	
        // Set the values for the Task object
    	this.appointmentID = appointmentID;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }
    
    // Private helper method to check the validity of the string field
    private void checkStringField(String field, int maxLength, String fieldName) {
        if (field == null || field.length() > maxLength) {
            throw new IllegalArgumentException("Invalid " + fieldName);
        }
    }
    
    // Private helper method to check the validity of the input field
    private void checkValidDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }
    }

    // Getter and setter for the Appointment ID
    public String getAppointmentID() {
        return appointmentID;
    }

    // Getter & Setter for the Appointment Date
    public Date getAppointmentDate() {
        return appointmentDate;
    }
    
    public void setAppointmentDate(Date appointmentDate) {
        // Check the validity of the updated appointmentDate
    	checkValidDate(appointmentDate);
		this.appointmentDate = appointmentDate;
	}

    // Getter & Setter for the Description
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        // Check the validity of the updated description
        checkStringField(description, 50, "description");
		this.description = description;
    }


}
