package test;

import com.*;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;


public class AppointmentServiceTest {
	// Declare the TaskService instance
    private AppointmentService appointmentService;

    @BeforeEach
    public void setUp() {
        // Initialize the AppointmentService instance before each test
    	appointmentService = new AppointmentService();
    }

    @Test
    public void testValidAddAppointment() {
    	// Create an appointment and add it to the service
        Date appointmentDate = addDays(new Date(), 1);
        Appointment appointment = new Appointment("01", appointmentDate, "Valid description");
        appointmentService.addAppointment(appointment);

        // Check that the appointment was added correctly
        assertEquals(appointment, appointmentService.getAppointments().get("01"));
    }

    @Test
    public void testInvalidAddAppointmentID() {
        // Create an appointment with an existing appointment ID
        Date appointmentDate = addDays(new Date(), 1);
        Appointment appointment = new Appointment("01", appointmentDate, "Duplicated Appointment ID 1");

        // Add the first appointment
        appointmentService.addAppointment(appointment);

        // Try to add the second appointment with the same ID
        assertThrows(IllegalArgumentException.class, () ->{	
        		Appointment duplicatedAppointment = new Appointment("01", appointmentDate, "Duplicated Appointment ID 2");
        		appointmentService.addAppointment(duplicatedAppointment);
        });
    }

    @Test
    public void testValidDeleteAppointment() {
        // Create an appointment and add it to the service
        Date appointmentDate = addDays(new Date(), 1);
        Appointment appointment = new Appointment("01", appointmentDate, "Valid description");
        appointmentService.addAppointment(appointment);

        // Delete the appointment
        appointmentService.deleteAppointment("01");

        // Verify appointment is deleted successfully
        assertNull(appointmentService.getAppointments().get("01"));
    }

    @Test
    public void testInvalidDeleteAppointmentID() {
        // Try to delete an appointment with a nonexistent ID
        assertThrows(IllegalArgumentException.class, () ->
        appointmentService.deleteAppointment("01")
        );
    }
    
    // Helper method to add days to a date
    private Date addDays(Date date, int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_YEAR, days);
        return calendar.getTime();
    }
}