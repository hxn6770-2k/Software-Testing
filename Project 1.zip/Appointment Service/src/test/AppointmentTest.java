package test;

import com.Appointment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        // Create a valid appointment
        Date appointmentDate = addDays(new Date(), 1); // Set the appointment date to tomorrow
        Appointment appointment = new Appointment("01", appointmentDate, "Valid appointment description");

        // Check that the values were set correctly
        assertEquals("01", appointment.getAppointmentID());
        assertEquals(appointmentDate, appointment.getAppointmentDate());
        assertEquals("Valid appointment description", appointment.getDescription());
    }

    @Test
    public void testAppointmentID() {
        Date appointmentDate = addDays(new Date(), 1);
        
        // Test creation of an appointment with a null ID
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(null, appointmentDate, "Null appointment ID")
        );
        
        // Create an appointment with an invalid ID (more than 10 characters)
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345678901", appointmentDate, "Invalid appointment ID")
        );

        // Create an appointment with a valid ID (less than 10 characters)
        assertDoesNotThrow(() ->
                new Appointment("123456789", appointmentDate, "Valid appointment ID")
        );
        
        // Create an appointment with a valid ID (exactly 10 characters)
        assertDoesNotThrow(() ->
                new Appointment("1234567890", appointmentDate, "Valid appointment ID")
        );
        
        // Test that the appointment ID is not updatable after appointment creation
        String appointmentID = "123";
        Appointment appointment = new Appointment(appointmentID, appointmentDate, "Test appointment");

        // Attempt to update the appointment ID (which should not be allowed)
        try {
        	appointmentID = "456";
        } catch (UnsupportedOperationException e) {
        	// An exception is expected here since the appointment ID is not updatable
        }

        // Ensure that the appointment ID remains unchanged
        assertEquals("123", appointment.getAppointmentID());
    }

    @Test
    public void testAppointmentDate() {
        Date appointmentDate = addDays(new Date(), -1); // Set the appointment date to yesterday

        // Create an appointment with an invalid date (in the past)
        assertThrows(IllegalArgumentException.class, () ->
               	new Appointment("01", appointmentDate, "Invalid appointment date")
        );
        
        // Test creation of an appointment with a null date
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("01", null, "Null appointment date")
        );
    }

    @Test
    public void testDescription() {
        Date appointmentDate = addDays(new Date(), 1);
        
        // Create an appointment with a valid description (less than 50 characters)
        assertDoesNotThrow(() ->
                new Appointment("01", appointmentDate, "Valid description")
        );

        // Create an appointment with a valid description (exactly 50 characters)
        assertDoesNotThrow(() ->
                new Appointment("01", appointmentDate, "01234567890123456789012345678901234567890123456789")
        );
        
        // Create an appointment with an invalid description (more than 50 characters)
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("01", appointmentDate, "Invalid description with more than 50 characters..................")
        );
        
        // Create an appointment with a null description
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("01", appointmentDate, null)
        );
    }

    // Helper method to add days to a date
    private Date addDays(Date date, int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_YEAR, days);
        return calendar.getTime();
    }
}
