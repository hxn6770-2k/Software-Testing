package com;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    // Declare a map to store tasks
    private Map<String, Task> tasksMap;

    // Constructor to initialize the TaskService
    public TaskService() {
        tasksMap = new HashMap<>();
    }

    // Add a task to the TaskService
    public void addTask(Task task) {
        // Check if the task ID already exists
        String taskID = task.getTaskID();
        if (tasksMap.containsKey(taskID)) {
            throw new IllegalArgumentException("Task ID already exists.");
        }

        // Add the task to the tasks map
        tasksMap.put(taskID, task);
    }

    // Delete a task to the TaskService
    public void deleteTask(String taskID) {
        // Check if the task ID exists
        if (!tasksMap.containsKey(taskID)) {
            throw new IllegalArgumentException("Task ID not found.");
        }

        // Remove the task from the tasks map
        tasksMap.remove(taskID);
    }

    // Update a task to the TaskService
    public void updateTask(String taskID, String name, String description) {
    	if (tasksMap.containsKey(taskID)) {
            // Retrieve the task from the tasksMap
			Task task = tasksMap.get(taskID);
			
            // Update the task with the new values
			task.setName(name);
			task.setDescription(description);
		} else {
			throw new IllegalArgumentException("Contact ID not found.");
		}
	}
	  
 // Getter to retrieve the tasksMap
 	public Map<String, Task> getTasks() {
         return tasksMap;
     }

}
