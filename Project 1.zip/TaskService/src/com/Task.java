package com;

public class Task {
	// Declare private member variables
	private String taskID;
    private String name;
    private String description;

    // Constructor to initialize the Task object
    public Task(String taskID, String name, String description) {
        // Check the validity of input fields
    	checkStringField(taskID, 10, "task ID");
        checkStringField(name, 20, "name");
        checkStringField(description, 50, "description");
        
        // Set the values for the Task object
        this.taskID = taskID;
        this.name = name;
        this.description = description;
    }

    // Private helper method to check the validity of the string field
    private void checkStringField(String field, int maxLength, String fieldName) {
        if (field == null || field.length() > maxLength) {
            throw new IllegalArgumentException("Invalid " + fieldName);
        }
    }

    // Getter for the TaskID
    public String getTaskID() {
        return taskID;
    }

    // Getter & Setter for the Name
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        // Check the validity of the updated name
        checkStringField(name, 20, "name");
		this.name = name;
    }

    // Getter & Setter for the Description
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        // Check the validity of the updated description
        checkStringField(description, 50, "description");
		this.description = description;
    }

}

