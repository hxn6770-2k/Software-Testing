package com;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
	// Declare the TaskService instance
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        // Initialize the TaskService instance before each test
        taskService = new TaskService();
    }

    @Test
    public void testValidAddTask() {
        // Create a task
        Task task = new Task("01", "Task 1", "This is task 1");

        // Add the task to the task service
        taskService.addTask(task);

        // Verify task is added successfully
        assertEquals(task, taskService.getTasks().get("01"));
    }
    
    @Test
	public void testInvalidAddTask() {
        // Create a valid Task object and add it to the TaskService
        Task task = new Task("01", "Task 1", "This is task 1");
        taskService.addTask(task);
		
        // Try adding a duplicate task with the same ID
        assertThrows(IllegalArgumentException.class, () -> {
        	Task duplicatedTask = new Task("01", "Task 2", "This is task 2");
        	taskService.addTask(duplicatedTask);
        });
	}
    
    @Test
    public void testValidDeleteTask() {
    	// Create a valid Task object and add it to the TaskService
        Task task = new Task("01", "Task 1", "This is task 1");
        taskService.addTask(task);

        // Delete the task
        taskService.deleteTask("01");

        // Verify task is deleted successfully
        assertNull(taskService.getTasks().get("01"));
    }
    
    @Test
	public void testInvalidDeleteTask() {
        // Try deleting a task with an non-exist ID
        assertThrows(IllegalArgumentException.class, () -> {
        taskService.deleteTask("01");
        });
	}

    @Test
    public void testValidUpdateTask() {
        // Create a task
        Task task = new Task("01", "Task 1", "This is task 1");

        // Add the task to the task service
        taskService.addTask(task);

        // Update the task name and task description
        taskService.updateTask("01", "New Task Name", "New Task Description");

        // Retrieve the updated contact from the ContactService
		Task updatedTask = taskService.getTasks().get("01");
		
		// Verify task name and description is updated
        assertEquals("New Task Name", updatedTask.getName());
        assertEquals("New Task Description", task.getDescription());
        }

    @Test
	 public void testInvalidUpdateTask() {
       // Try updating a contact with an non-exist ID
       assertThrows(IllegalArgumentException.class, () -> {
       taskService.updateTask("01", "Task 1", "This is task 1");
       });
	 }
}
