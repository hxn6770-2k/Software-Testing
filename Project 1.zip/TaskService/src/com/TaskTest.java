package com;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTask() {
        // Create a valid task
        Task task = new Task("01", "Task 1", "This is task 1");

        // Verify task fields
        assertEquals("01", task.getTaskID());
        assertEquals("Task 1", task.getName());
        assertEquals("This is task 1", task.getDescription());
    }

    @Test
    public void testTaskID() {
        // Test creation of a task with a null task ID
        assertThrows(IllegalArgumentException.class, () ->
            new Task(null, "Task 1", "This is task 1 with an invalid ID"));

        // Test creation of a task with a task ID exceeding the maximum length (more than 10 characters)
        assertThrows(IllegalArgumentException.class, () ->
            new Task("0123456789A", "Task 1", "This is task 1 with an invalid ID"));

        // Create a task with a valid ID (less than 10 characters)
        assertDoesNotThrow(() ->
            new Task("123456789", "Task 1", "This is task 1 with a valid ID")
        );

        // Create a task with a valid ID (exactly 10 characters)
        assertDoesNotThrow(() ->
            new Task("1234567890", "Task 1", "This is task 1 with a valid ID")
        );

        // Test creation of a task with a valid task ID
        String taskID = "123";
        Task task = new Task(taskID, "Task 1", "This is task 1 with a valid ID");

        // Attempt to update the task ID (which should not be allowed)
        try {
            taskID = "456";
        } catch (UnsupportedOperationException e) {
            // An exception is expected here since the task ID is not updatable
        }

        // Ensure that the task ID remains unchanged
        assertEquals("123", task.getTaskID());
    }


    @Test
    public void testName() {
    	// Test creation of a task with null name
        assertThrows(IllegalArgumentException.class, () ->
                new Task("01", null, "This is task 1"));
        
        // Test creation of a task with a name exceeding the maximum length (more than 20 characters)
        assertThrows(IllegalArgumentException.class, () ->
                new Task("01", "Task 1 with a very long name", "This is task 1"));

        // Test creation of a task with a name equal to the maximum length (exactly 20 characters)
        assertDoesNotThrow(() ->
                new Task("02", "Task 2 with 20 chars", "This is task 2"));

        // Test creation of a task with a name less than 20 characters
        assertDoesNotThrow(() ->
                new Task("03", "Short task name", "This is task 3"));
    }


    @Test
    public void testDescription() {
        // Create a task with a description exceeding the maximum length
        assertThrows(IllegalArgumentException.class, () ->
                new Task("01", "Task 1", "This is task 1 with a very long description that exceeds the maximum length limit."));

        // Create a task with a valid description (less than or equal to the maximum length)
        assertDoesNotThrow(() ->
                new Task("02", "Task 2", "Short description"));

        // Create a task with a null description
        assertThrows(IllegalArgumentException.class, () ->
                new Task("03", "Task 3", null));
    }


}
