package com;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContact() {
        // Test valid contact creation
        Contact contact = new Contact("01", "Jayson", "Davis", "1234567890", "123 Barton Dr");

        // Verify the attributes of the contact
        assertEquals("01", contact.getContactID());
        assertEquals("Jayson", contact.getFirstName());
        assertEquals("Davis", contact.getLastName());
        assertEquals("1234567890", contact.getPhoneNumber());
        assertEquals("123 Barton Dr", contact.getAddress());
    }
    
    @Test
    public void testContactID() {
        // Test creation of a contact with a null contact ID
        assertThrows(IllegalArgumentException.class, () 
        		-> new Contact(null, "Jayson", "Davis", "1234567890", "123 Barton Dr"));
        
        // Test creation of a contact with a contact ID exceeding the maximum length (more than 10 characters)
        assertThrows(IllegalArgumentException.class, () 
        		-> new Contact("0123456789A", "Jayson", "Davis", "1234567890", "123 Barton Dr"));
        
        // Create an contact with a valid ID (less than 10 characters)
        assertDoesNotThrow(() 
        		-> new Contact("123456789", "Jayson", "Davis", "1234567890", "123 Barton Dr")
        );
        
        // Create an appointment with a valid ID (exactly 10 characters)
        assertDoesNotThrow(() 
        		-> new Contact("1234567890", "Jayson", "Davis", "1234567890", "123 Barton Dr")
        );
        
        // Test creation of a contact with a valid contact ID
        String contactID = "123";
        Contact contact = new Contact(contactID, "Jayson", "Davis", "1234567890", "123 Barton Dr");

        // Attempt to update the contact ID (which should not be allowed)
        try {
            contactID = "456";
        } catch (UnsupportedOperationException e) {
            // An exception is expected here since the contact ID is not updatable
        }

        // Ensure that the contact ID remains unchanged
        assertEquals("123", contact.getContactID());
    }

    @Test
    public void testLastName() {
    	// Test creation of a contact with a null last name
    	assertThrows(IllegalArgumentException.class, () 
    			-> new Contact("01", "Jayson", null, "1234567890", "123 Barton Dr"));

    	// Test creation of a contact with a last name exceeding the maximum length (greater than 10 characters)
    	assertThrows(IllegalArgumentException.class, () 
    			-> new Contact("01", "Jayson", "Davis1234567", "1234567890", "123 Barton Dr"));

    	// Test creation of a contact with a last name equal to the maximum length (10 characters)
    	assertDoesNotThrow(() 
    			-> new Contact("02", "John", "SmithDoe", "0987654321", "456 Elm St"));

    	// Test creation of a contact with a last name less than 10 characters
    	assertDoesNotThrow(() 
    			-> new Contact("03", "James", "Smith", "5678901234", "789 Oak Ave"));
    }

    @Test
    public void testPhoneNumber() {
        // Test creation of a contact with a null phone number
        assertThrows(IllegalArgumentException.class, () 
        		-> new Contact("01", "Jayson", "Davis", null, "123 Barton Dr"));

       // Test creation of a contact with a phone number containing non-digit characters
        assertThrows(IllegalArgumentException.class, () 
        		-> new Contact("01", "Jayson", "Davis", "123-456-7890", "123 Barton Dr"));

        // Test creation of a contact with a phone number less than 10 digits
        assertThrows(IllegalArgumentException.class, () 
        		-> new Contact("01", "Jayson", "Davis", "123456789", "123 Barton Dr"));

        // Test creation of a contact with a phone number greater than 10 digits
        assertThrows(IllegalArgumentException.class, () 
        		-> new Contact("01", "Jayson", "Davis", "12345678901", "123 Barton Dr"));

        // Test creation of a contact with a valid phone number (exactly 10 digits)
        assertDoesNotThrow(() 
        		-> new Contact("02", "John", "Smith", "0987654321", "456 Elm St"));

        // Test creation of a contact with a invalid phone number (including non-digit characters but exactly 10 digits)
        assertThrows(IllegalArgumentException.class, () 
        		-> new Contact("03", "James", "Johnson", "(567) 890-1234", "789 Oak Ave"));
    }


    @Test
    public void testInvalidAddress() {
        // Test creation of a contact with an address exceeding the maximum length (greater than 50 characters)
        assertThrows(IllegalArgumentException.class, () -> new Contact("01", "Jayson", "Davis", "1234567890", "123 Barton Dr11111111111111111111111111111111111111111111111111111111111111111111111111"));

        // Test creation of a contact with an address equal to the maximum length (50 characters)
        assertDoesNotThrow(() -> new Contact("02", "John", "Smith", "0987654321", "456 Elm St, Apt 5555555555"));

        // Test creation of a contact with an address less than 50 characters
        assertDoesNotThrow(() -> new Contact("03", "James", "Johnson", "5678901234", "789 Oak Ave"));
    }

}
