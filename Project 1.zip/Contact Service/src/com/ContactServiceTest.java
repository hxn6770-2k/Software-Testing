package com;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	// Declare the ContactService instance
	private ContactService contactService;

	@BeforeEach
	public void setUp(){
        // Initialize the ContactService instance before each test
		contactService = new ContactService();
	}

	@Test
	public void testValidAddContact() {
        // Create a valid Contact object
		Contact contact = new Contact("01", "Jayson", "Davis", "1234567890", "123 Barton Dr");
		
        // Add the contact to the ContactService
		contactService.addContact(contact);  
		
        // Retrieve the added contact from the ContactService
		Contact retrivedContact = contactService.getContacts().get("01");
		
        // Verify that the retrieved contact is the same as the added contact
		assertEquals(contact, retrivedContact);  //
	}
	
	@Test
	public void testInvalideAddContact() {
        // Create a valid Contact object and add it to the ContactService
		Contact contact = new Contact("01", "Jayson", "Davis", "1234567890", "123 Barton Dr");
		contactService.addContact(contact);
		
        // Try adding a duplicate contact with the same ID
        assertThrows(IllegalArgumentException.class, () -> {
        	Contact duplicatedContact = new Contact("01", "Jack", "Newton", "9876543210", "345 Fossil Hill Dr");
        	contactService.addContact(duplicatedContact);
        });
	}
	
	@Test
	public void testValidDeleteContact() {
        // Create a valid Contact object and add it to the ContactService
		Contact contact = new Contact("01", "Jayson", "Davis", "1234567890", "123 Barton Dr");
		contactService.addContact(contact);
		
		// Delete the contact with the given ID from the ContactService
		contactService.deleteContact("01");
		
        // Verify that the contact has been deleted from the ContactService
		assertFalse(contactService.getContacts().containsKey("01"));

	}
	
	@Test
	public void testInvalidDeleteContact() {
        // Try deleting a contact with an non-exist ID
        assertThrows(IllegalArgumentException.class, () -> {
        	contactService.deleteContact("01");
        });
	}
	
	@Test
	public void testValidUpdateContact() {
        // Create a valid Contact object and add it to the ContactService
		Contact contact = new Contact("01", "Jayson", "Davis", "1234567890", "123 Barton Dr");
		contactService.addContact(contact);
		
        // Update the contact with the given ID
		contactService.updateContact("01", "Jack", "Newton", "9876543210", "345 Fossil Hill Dr");
		
        // Retrieve the updated contact from the ContactService
		Contact updatedContact = contactService.getContacts().get("01");
		
        // Verify that the contact has been updated with the new values
		assertEquals("Jack", updatedContact.getFirstName());
        assertEquals("Newton", updatedContact.getLastName());
        assertEquals("9876543210", updatedContact.getPhoneNumber());
        assertEquals("345 Fossil Hill Dr", updatedContact.getAddress());
	}
	
	 @Test
	 public void testInvalidUpdateContact() {
        // Try updating a contact with a non-existent ID
        assertThrows(IllegalArgumentException.class, () -> {
        	contactService.updateContact("01", "Jane", "Smith", "9876543210", "456 Elm St");
        });
	 }
}
