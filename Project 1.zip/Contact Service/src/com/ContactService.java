package com;
import java.util.HashMap;
import java.util.Map;

public class ContactService {
    // Declare a map to store contacts
	private Map<String, Contact> contactsMap;
	
    // Constructor to initialize the ContactService
	public ContactService() {
		contactsMap = new HashMap<>();
	}
	
    // Add a contact to the ContactService
	public void addContact(Contact contact) {
		if (!contactsMap.containsKey(contact.getContactID())) {
		    // Add a contact to the ContactService
			contactsMap.put(contact.getContactID(), contact);  
		} else {
			throw new IllegalArgumentException("Contact ID already exists.");
		}
	}
	
    // Delete a contact from the ContactService
	public void deleteContact(String contactID) {
		if (contactsMap.containsKey(contactID)) {
            // Remove the contact from the contactsMap if the contact ID exists
			contactsMap.remove(contactID);
		} else {
			throw new IllegalArgumentException("Contact ID not found.");
		}
	}
	
    // Update a contact in the ContactService
	public void updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		if (contactsMap.containsKey(contactID)) {
            // Retrieve the contact from the contactsMap
			Contact contact = contactsMap.get(contactID);
			
            // Update the contact with the new values
			contact.setFirstName(firstName);
			contact.setLastName(lastName);
			contact.setPhoneNumber(phoneNumber);
			contact.setAddress(address);
			
		} else {
			throw new IllegalArgumentException("Contact ID not found.");
		}
	}
	
    // Getter to retrieve the contactsMap
	public Map<String, Contact> getContacts() {
        return contactsMap;
    }

}
