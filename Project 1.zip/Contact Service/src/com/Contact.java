package com;

public class Contact {
	// Declare private member variables
	private String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
    // Constructor to initialize the Contact object
	public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
        // Check the validity of input fields
		checkContactID(contactID);
		checkStringField(firstName, "firstName", 10);
		checkStringField(lastName, "lastName", 10);
		checkPhoneNumber(phoneNumber);
		checkStringField(address, "address", 30);
		
        // Set the values for the Contact object
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}
	
    // Getter for the contactID
	public String getContactID() {
		return contactID;
	}
	
    // Getter for the contactID
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
        // Check the validity of the updated firstName
		checkStringField(firstName, "firstName", 10);
		this.firstName = firstName;
	}
	
    // Getter and setter for the lastName
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
        // Check the validity of the updated lastName
		checkStringField(lastName, "lastName", 10);
		this.lastName = lastName;
	}
	
    // Getter and setter for the phoneNumber
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public void setPhoneNumber(String phoneNumber) {
        // Check the validity of the updated phoneNumber
		checkPhoneNumber(phoneNumber);
		this.phoneNumber = phoneNumber;
	}
	
    // Getter and setter for the address
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
        // Check the validity of the updated address
		checkStringField(address, "address", 30);
		this.address = address;
		
	}
	
    // Private helper method to check the validity of the contactID
	private void checkContactID(String contactID) {
		if (contactID == null || contactID.isEmpty() || contactID.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID.");
		}
	}
	
    // Private helper method to check the validity of string fields
	private void checkStringField(String field, String fieldName, int maxLength) {
		if(field == null || field.isEmpty() || field.length()>maxLength) {
			throw new IllegalArgumentException("Invalid " + fieldName + ".");
		}
	}
	
    // Private helper method to check the validity of the phoneNumber
	private void checkPhoneNumber(String phoneNumber) {
		if (phoneNumber == null || phoneNumber.length() != 10) {
	        throw new IllegalArgumentException("Invalid phone number. Phone number must contain exactly 10 digits.");
	    }
		
		// Iterate over each character in the phoneNumber string
		for (char digit: phoneNumber.toCharArray()) {
			// Check if the current character is a digit
			if (!Character.isDigit(digit)) {
	            throw new IllegalArgumentException("Invalid phone number. Phone number must contain only digits.");
	        }
		}
	}

}
